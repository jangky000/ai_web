package dev.mvc.cate;

import dev.mvc.categrp.CategrpVO;

public class Categrp_Cate_VO {
  private CategrpVO categrpVO;
  private CateVO cateVO;
  
  public CategrpVO getCategrpVO() {
    return categrpVO;
  }
  public void setCategrpVO(CategrpVO categrpVO) {
    this.categrpVO = categrpVO;
  }
  public CateVO getCateVO() {
    return cateVO;
  }
  public void setCateVO(CateVO cateVO) {
    this.cateVO = cateVO;
  }

  
}
